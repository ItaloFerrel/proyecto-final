﻿namespace SQLite.CodeFirst.NetCore.Console.Entity
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
