﻿namespace SQLite.CodeFirst.Statement.ColumnConstraint
{
    internal interface IColumnConstraint : IStatement { }
}
