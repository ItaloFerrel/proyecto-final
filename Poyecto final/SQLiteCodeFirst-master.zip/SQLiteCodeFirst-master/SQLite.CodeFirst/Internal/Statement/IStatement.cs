﻿namespace SQLite.CodeFirst.Statement
{
    public interface IStatement
    {
        string CreateStatement();
    }
}
