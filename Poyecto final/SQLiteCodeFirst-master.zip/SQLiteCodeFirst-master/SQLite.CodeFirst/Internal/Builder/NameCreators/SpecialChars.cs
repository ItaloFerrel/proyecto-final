﻿namespace SQLite.CodeFirst.Builder.NameCreators
{
    internal class SpecialChars
    {
        public const char EscapeCharOpen = '\"';
        public const char EscapeCharClose = '\"';
    }
}
