﻿namespace SQLite.CodeFirst.Console.Entity
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
